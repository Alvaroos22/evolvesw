
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpSession;
import model.Cliente;
import util.ClienteDao;
import model.Proveedor;
import util.ProveedorDao;
import util.Log;




public class ClienteController extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static String INSERT_OR_EDIT = "/user.jsp";
    private static String LIST_USER = "/listUser.jsp";
    private ClienteDao dao;
    private ProveedorDao daoProveedor;
    private Log log;

    public ClienteController() {
        super();
        daoProveedor = new ProveedorDao();
        dao = new ClienteDao();
    }
   
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String forward = "";
        Log.log.info("Entramos en el doGet");
        
        RequestDispatcher view = request.getRequestDispatcher(forward);
        view.forward(request, response);
        return;
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    //@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Log.log.info("Entramos por el doPost");
        
        
/*        processRequest(request, response); */
String accion = request.getParameter("accion");
String origen = request.getParameter("origen");
String usuario = "";
String email = "";
String contraseña = "";
       
             HttpSession session = request.getSession();
           Cliente cliente = new Cliente();
           Proveedor proveedor = new Proveedor();
           if (accion.equals("registro")){ // Hacen el registro
               
                        if(origen.equals("Cliente")){  // REGISTRAR CLIENTE
                          java.util.Date d = new java.util.Date();  
                          java.sql.Date date2 = new java.sql.Date(d.getTime());

                          usuario = request.getParameter("usuarioRegistro");
                          email = request.getParameter("emailRegistro");
                          contraseña = request.getParameter("contraseniaRegistro");
                          cliente.setNombre(usuario);
                          cliente.setEmail(email);
                          cliente.setProyectos_publicados(0);
                          cliente.setContraseña(contraseña);
                          cliente.setFecha_registro(date2);
               
                          Cliente resultadoCliente = dao.getUserByEmail(cliente.getEmail());
                          String emailBuscarCliente = resultadoCliente.getEmail();
                          Proveedor resultadoProveedor = daoProveedor.getProveedorByEmail(cliente.getEmail());
                          String emailBuscarProveedor = resultadoProveedor.getEmail();

                          if(emailBuscarCliente.equals("") && emailBuscarProveedor.equals("")){
                                dao.addUser(cliente);
                                session.setAttribute("validar","");
                                session.setAttribute("cliente", cliente);
                                session.setAttribute("nombreCliente", cliente.getNombre());
                                session.setAttribute("emailCliente", cliente.getEmail());
                                session.setAttribute("fechaCliente", cliente.getFecha_registro());
                                
                                session.setAttribute("origen", "Cliente");
                                 RequestDispatcher view = request.getRequestDispatcher("/clientView.jsp");            
                                 view.forward(request, response);
                                 return;

                          }else{


                              session = request.getSession();
                              session.setAttribute("validar","Ya existe");
                              RequestDispatcher view = request.getRequestDispatcher("/login.jsp");            
                                    view.forward(request, response);
                               return;

                          } 
                        }else{ //REGISTRAR PROVEEDOR
                            
                            java.util.Date d = new java.util.Date();  
                          java.sql.Date date2 = new java.sql.Date(d.getTime());

                          usuario = request.getParameter("usuarioRegistro");
                          email = request.getParameter("emailRegistro");
                          contraseña = request.getParameter("contraseniaRegistro");
                          proveedor.setNombre(usuario);
                          proveedor.setEmail(email);
                          proveedor.setContraseña(contraseña);
                          proveedor.setFecha_registro(date2);
               
                          Cliente resultadoCliente = dao.getUserByEmail(proveedor.getEmail());
                          String emailBuscarCliente = resultadoCliente.getEmail();
                          Proveedor resultadoProveedor = daoProveedor.getProveedorByEmail(proveedor.getEmail());
                          String emailBuscarProveedor = resultadoProveedor.getEmail();

                          if(emailBuscarCliente.equals("") && emailBuscarProveedor.equals("")){
                                
                                daoProveedor.addProveedor(proveedor);
                                session.setAttribute("validar","");
                                session.setAttribute("proveedor", proveedor);
                                session.setAttribute("nombreProveedor", proveedor.getNombre());
                                session.setAttribute("emailProveedor", proveedor.getEmail());
                                session.setAttribute("fechaProveedor", proveedor.getFecha_registro());
                                session.setAttribute("origen", "Proveedor");
                                 RequestDispatcher view = request.getRequestDispatcher("/index.jsp");            
                                 view.forward(request, response);
                                 return;

                          }else{


                              session = request.getSession();
                              session.setAttribute("validar","Ya existe");
                              RequestDispatcher view = request.getRequestDispatcher("/login.jsp");            
                                    view.forward(request, response);
                               return;

                          } 

                        }  
               
           }else { //HaceR el LOGIN
               usuario = request.getParameter("usuarioInicio");
               contraseña = request.getParameter("contraseniaInicio");
               cliente.setNombre(usuario);
               cliente.setEmail(email);
               
               Cliente resultado = dao.getUserRegister(usuario,contraseña);
               String nombreBuscarCliente = resultado.getNombre();
               Proveedor resultadoProveedor =daoProveedor.getProveedorRegister(usuario, contraseña);
               String nombreBuscarProveedor = resultadoProveedor.getNombre();
               
               
               if(nombreBuscarCliente.equals("") && nombreBuscarProveedor.equals("")){
                   
                   
                   session.setAttribute("validar","No existe login");
                   
               
                RequestDispatcher view = request.getRequestDispatcher("/login.jsp");            
                view.forward(request, response);
                return;
                   
                   
               }else if (!nombreBuscarCliente.equals("")){
                   
                   //dao.addUser(cliente);
               session.setAttribute("validar","");
               session.setAttribute("cliente", cliente);
               session.setAttribute("origen", "Cliente");
               session.setAttribute("nombreCliente", cliente.getNombre());
               session.setAttribute("emailCliente", resultado.getEmail());
               session.setAttribute("fechaCliente", resultado.getFecha_registro());
               
               
                RequestDispatcher view = request.getRequestDispatcher("/clientView.jsp");            
                view.forward(request, response);
                return;
                 
                   
               }else if (!nombreBuscarProveedor.equals("")){
                   
                   //dao.addUser(cliente);
               session.setAttribute("validar","");
               session.setAttribute("proveedor", cliente);
               session.setAttribute("origen", "Proveedor");
               session.setAttribute("nombreProveedor", cliente.getNombre());
               session.setAttribute("emailProveedor", resultadoProveedor.getEmail());
               session.setAttribute("fechaProveedor", resultadoProveedor.getFecha_registro());
                RequestDispatcher view = request.getRequestDispatcher("/index.jsp");            
                view.forward(request, response);
                return; 
                
               }
               
               
               
           }
           
       


       
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

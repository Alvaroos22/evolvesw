
package controller;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.DateFormat;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import model.Cliente;
import model.Presupuesto;
import util.ClienteDao;
import util.Log;
import util.ProveedorDao;
import model.Proveedor;
import org.springframework.web.multipart.MultipartRequest;
import util.ProveedorDao;
import model.Proyecto;
import util.ProyectoDao;
import util.PresupuestoDao;




//@WebServlet("/upload")
@MultipartConfig
public class PublicarProyectoController extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static String INSERT_OR_EDIT = "/user.jsp";
    private static String LIST_USER = "/listUser.jsp";
    private ClienteDao dao;
    private PresupuestoDao daoPresupuesto;
    private ProveedorDao daoProveedor;
    private ProyectoDao daoProyecto;
    private Log log;

    public PublicarProyectoController() {
        super();
         daoProveedor = new ProveedorDao();
        dao = new ClienteDao();
        daoProyecto = new ProyectoDao();
        daoPresupuesto = new PresupuestoDao();
    }
   
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String forward = "";
        Log.log.info("Entramos en el doGet");
        
       HttpSession session = request.getSession();
        session.invalidate();
        String id_proyecto = request.getParameter("id_proyecto");
    response.sendRedirect("login.jsp");
    return; // <--- Here.
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    //@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Log.log.info("Entramos por el doPost");
        HttpSession session = request.getSession();
        Presupuesto presupuesto = new Presupuesto();
        Proyecto proyecto = new Proyecto();
        
        Proveedor resultadoProveedor = daoProveedor.getProveedorByEmail((String) session.getAttribute("emailProveedor"));
        
        String proyectDetail = request.getParameter("proyectDetail");
        String id_proyecto = request.getParameter("id_proyecto");
        
        proyecto = daoProyecto.getProyectoDetalle(Integer.parseInt(id_proyecto));
        
        java.util.Date d = new java.util.Date();  
        java.sql.Date date2 = new java.sql.Date(d.getTime());
        
        presupuesto.setArchivo("");
        presupuesto.setComentarios(proyectDetail);
        presupuesto.setEstado("Pendiente");
        presupuesto.setId_proyecto(Integer.parseInt(id_proyecto));
        presupuesto.setId_proveedor(resultadoProveedor.getId_usuario());
        presupuesto.setFecha_propuesta(date2);
        presupuesto.setNombreProyecto(proyecto.getNombre());
        presupuesto.setAceptada("");
        
        
        
        
        int insertado = daoPresupuesto.addPresupuesto(presupuesto);
        
        Part filePart = request.getPart("documento"); // Retrieves <input type="file" name="file">
        
       
        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString(); // MSIE fix.
        InputStream fileContent = filePart.getInputStream();
        
        String path="/documentos/propuestas";
        //String path="/opt/tomcat/webapps";
        
        File uploads = new File(path); //Carpeta donde se guardan los archivos
        uploads.mkdirs(); //Crea los directorios necesarios
        File file = File.createTempFile("Propuestas-"+insertado+"-", "-"+fileName, uploads); //Evita que hayan dos archivos con el mismo nombre
        String nombreFichero = file.getName();
        try (InputStream input = filePart.getInputStream()){
            Files.copy(input, file.toPath(), StandardCopyOption.REPLACE_EXISTING);
        }
         
        daoPresupuesto.updatePresupuestoDocumento(nombreFichero, insertado);
         
         
        daoProyecto.updateEstadoProyecto("Pendiente", Integer.parseInt(id_proyecto));
      
       
       
        
        List<Proyecto> proyectos = daoProyecto.getAllProyecto();
        
        request.setAttribute("proyectos", proyectos);
       
         
    RequestDispatcher view = request.getRequestDispatcher("/buscarProyecto.jsp");            
                view.forward(request, response);
                return;

     
        
        
      
       
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    
    

}

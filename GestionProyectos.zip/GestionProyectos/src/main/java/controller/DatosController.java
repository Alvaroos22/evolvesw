
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpSession;
import model.Cliente;
import util.ClienteDao;
import util.Log;
import util.ProveedorDao;
import model.Proveedor;
import util.PresupuestoDao;
import util.ProveedorDao;
import util.ProyectoDao;



public class DatosController extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static String INSERT_OR_EDIT = "/user.jsp";
    private static String LIST_USER = "/listUser.jsp";
    private ClienteDao dao;
    private ProveedorDao daoProveedor;
    private Log log;

    public DatosController() {
        super();
         daoProveedor = new ProveedorDao();
        dao = new ClienteDao();
    }
   
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String forward = "";
        Log.log.info("Entramos en el doGet");
        
       HttpSession session = request.getSession();
        
    response.sendRedirect("login.jsp");
    return; // <--- Here.
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    //@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Log.log.info("Entramos por el doPost");
        HttpSession session = request.getSession();
        int num_ejecucionCliente = 0;
    int num_completadoCliente = 0;
    int num_ejecucionProveedor = 0;
    int num_completadoProveedor = 0;
    if(session.getAttribute("origen")=="Cliente"){
        
        ProyectoDao daoProyecto = new ProyectoDao();
        ClienteDao daoCliente = new ClienteDao();
        Cliente cliente = new Cliente();
        
        Cliente resultadoCliente = daoCliente.getUserByEmail( (String) session.getAttribute("emailCliente"));
        
         num_ejecucionCliente = daoProyecto.getNumProyectoEjecucion(resultadoCliente.getId_usuario());
        
         num_completadoCliente = daoProyecto.getNumProyectoCompletados(resultadoCliente.getId_usuario());
    }else{
        PresupuestoDao daoPresupuesto = new PresupuestoDao();
        ProveedorDao daoProveedor = new ProveedorDao();
        Proveedor proveedor = new Proveedor();
        
        Proveedor resultadoProveedor = daoProveedor.getProveedorByEmail( (String) session.getAttribute("emailProveedor"));
        
        num_ejecucionProveedor = daoPresupuesto.getNumProyectoEjecucion(resultadoProveedor.getId_usuario());
        
        num_completadoProveedor = daoPresupuesto.getNumProyectoCompletados(resultadoProveedor.getId_usuario());
    }
            request.setAttribute("num_ejecucionCliente", num_ejecucionCliente);
            request.setAttribute("num_completadoCliente", num_completadoCliente);
            request.setAttribute("num_ejecucionProveedor", num_ejecucionProveedor);
            request.setAttribute("num_completadoProveedor", num_completadoProveedor);
            
            RequestDispatcher view = request.getRequestDispatcher("/account.jsp");            
                                 view.forward(request, response);
                                 return;
            
        
        
      
       
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}


package controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.DateFormat;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpSession;
import model.Cliente;
import util.ClienteDao;
import util.Log;
import util.ProveedorDao;
import model.Proveedor;
import model.Proyecto;
import util.PresupuestoDao;
import util.ProveedorDao;
import util.ProyectoDao;




public class AceptarController extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static String INSERT_OR_EDIT = "/user.jsp";
    private static String LIST_USER = "/listUser.jsp";
    private ClienteDao dao;
    private ProveedorDao daoProveedor;
    private Log log;

    public AceptarController() {
        super();
         daoProveedor = new ProveedorDao();
        dao = new ClienteDao();
    }
   
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String forward = "";
        Log.log.info("Entramos en el doGet");
        
       HttpSession session = request.getSession();
        
    response.sendRedirect("login.jsp");
    return; // <--- Here.
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    //@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Log.log.info("Entramos por el doPost");
        HttpSession session = request.getSession();
        
         response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        String estadoProyecto = request.getParameter("estadoProyecto");
        String proyectoId = request.getParameter("proyectoId");
        String aceptadaPropuesta = request.getParameter("aceptadaPropuesta");
        String presupuestoId = request.getParameter("presupuestoId");
       
        
        ProyectoDao daoProyecto = new ProyectoDao();
        ClienteDao daoCliente = new ClienteDao();
        Cliente cliente = new Cliente();
        
        PresupuestoDao daoPresupuesto = new PresupuestoDao();
        ProveedorDao daoProveedor = new ProveedorDao();
        Proveedor proveedor = new Proveedor();
        
        if(estadoProyecto.equals("Pendiente")){
            estadoProyecto = "Análisis de impacto";
            
        }else if (estadoProyecto.equals("Análisis de impacto") && aceptadaPropuesta.equals("Si")){
            estadoProyecto = "Análisis funcional";
        }else if (estadoProyecto.equals("Análisis de impacto") && aceptadaPropuesta.equals("No")){
            estadoProyecto = "Análisis de impacto";    
        }else if (estadoProyecto.equals("Análisis funcional") && aceptadaPropuesta.equals("Si")){
            estadoProyecto = "Plan de pruebas";
        }else if (estadoProyecto.equals("Análisis funcional") && aceptadaPropuesta.equals("No")){
            estadoProyecto = "Análisis funcional";        
        }else if (estadoProyecto.equals("Plan de pruebas") && aceptadaPropuesta.equals("Si")){
            estadoProyecto = "Completado";    
        }else if (estadoProyecto.equals("Plan de pruebas") && aceptadaPropuesta.equals("No")){
            estadoProyecto = "Plan de pruebas";
        }
        
        daoProyecto.updateEstadoProyecto(estadoProyecto, Integer.parseInt(proyectoId));
        daoPresupuesto.updatePresupuestoAceptada("Si",Integer.parseInt(presupuestoId) );
        daoPresupuesto.updatePresupuestoEstado(estadoProyecto, Integer.parseInt(presupuestoId));
        
         Cliente resultadoCliente = dao.getUserByEmail((String) session.getAttribute("emailCliente"));
         
         
      List<Proyecto> proyectos = daoProyecto.getProyectoById(resultadoCliente.getId_usuario());
         
        request.setAttribute("proyectos", proyectos);
       
         
    RequestDispatcher view = request.getRequestDispatcher("/Formalities.jsp");            
                view.forward(request, response);
                return;
        
        
        
        
        
       
        
        
       
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

package controller;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.DateFormat;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import model.Cliente;
import model.Presupuesto;
import util.ClienteDao;
import util.Log;
import util.ProveedorDao;
import model.Proveedor;
import org.springframework.web.multipart.MultipartRequest;
import util.ProveedorDao;
import model.Proyecto;
import util.ProyectoDao;
import util.PresupuestoDao;




public class ProveedorProjecDetailController extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static String INSERT_OR_EDIT = "/user.jsp";
    private static String LIST_USER = "/listUser.jsp";
    private ClienteDao dao;
    private ProveedorDao daoProveedor;
    private ProyectoDao daoProyecto;
    private PresupuestoDao daoPresupuesto;
    private Log log;

    public ProveedorProjecDetailController() {
        super();
         daoProveedor = new ProveedorDao();
        dao = new ClienteDao();
        daoProyecto = new ProyectoDao();
        daoPresupuesto = new PresupuestoDao();
    }
   
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String forward = "";
        Log.log.info("Entramos en el doGet");
        
       HttpSession session = request.getSession();
        Proyecto proyecto = new Proyecto();
        
        List<Proyecto> proyectos = daoProyecto.getAllProyecto();
        
        request.setAttribute("proyectos", proyectos);
       
         
    RequestDispatcher view = request.getRequestDispatcher("/buscarProyecto.jsp");            
                view.forward(request, response);
                return;
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    //@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Log.log.info("Entramos por el doPost");
        HttpSession session = request.getSession();
        /*Proyecto proyecto = new Proyecto();
        Presupuesto presupuesto = new Presupuesto();
        Proveedor resultadoProveedor = daoProveedor.getProveedorByEmail((String) session.getAttribute("emailProveedor"));
        
        List<Presupuesto> presupuestos = daoPresupuesto.getPresupuestoById(resultadoProveedor.getId_usuario());
        
        
        
        
        request.setAttribute("presupuestos", presupuestos);*/
        
        String proyecto_id = request.getParameter("id_proyecto");
        
        ProyectoDao daoProyecto = new ProyectoDao();
        
        Proyecto proyecto = daoProyecto.getProyectoDetalle(Integer.parseInt(proyecto_id));
        request.setAttribute("proyecto", proyecto);
        
         PresupuestoDao daoPresupuesto = new PresupuestoDao();
        Presupuesto presupuesto = daoPresupuesto.getPresupuestoDetalle(Integer.parseInt(proyecto_id));
        
        request.setAttribute("presupuesto", presupuesto);
       
         
    RequestDispatcher view = request.getRequestDispatcher("/proveedorProjectDetail.jsp");            
                view.forward(request, response);
                return;
         
         
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}


package util;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.Proyecto;
import util.DbUtil;
import util.Log;

public class ProyectoDao {

    private Connection connection;

    public ProyectoDao() {
        connection = DbUtil.getConnection();
    }

    public int addProyecto(Proyecto proyecto) {
        int insertId = 0;
        try {
            
            PreparedStatement preparedStatement = connection.prepareStatement("insert into proyectos(nombre,descripcion,presupuesto,fecha_subida,fecha_limite,documento,estado,id_cliente,extension_documento) values (?, ?, ?,?,?,?,?,? ,?)");
// Parameters start with 1 
            preparedStatement.setString(1, proyecto.getNombre());
            //preparedStatement.setString(2, user.getApellidos());            
            preparedStatement.setString(2, proyecto.getDescripcion());
            preparedStatement.setFloat(3,proyecto.getPresupueto());
            preparedStatement.setDate(4, (Date) proyecto.getFecha_subida());
            preparedStatement.setString(5,  proyecto.getFecha_limite());
            preparedStatement.setString(6, proyecto.getDocumento());
            preparedStatement.setString(7, proyecto.getEstado());
            preparedStatement.setInt(8, proyecto.getId_cliente());
            preparedStatement.setString(9, proyecto.getExtension_documento());
            preparedStatement.executeUpdate();
            
            PreparedStatement getLastInsertId = connection.prepareStatement("SELECT LAST_INSERT_ID()");
            ResultSet rs = getLastInsertId.executeQuery();
            if (rs.next()){
                    insertId = (int) rs.getLong("last_insert_id()");  
                    
            }
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
        
        return insertId;
    }

    public void deleteUser(int userId) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("delete from proyecto where id_proyecto=?");
            // Parameters start with 1 
            preparedStatement.setInt(1, userId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
    }
    
    public void updateProveedorDocumento(String documento,int proyecto_id) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("update proyectos set documento=?" + "where id_proyecto=?");
// Parameters start with 1 
            preparedStatement.setString(1, documento);
            preparedStatement.setInt(2, proyecto_id);            
            
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);            
        }
    }
    public void updateEstadoProyecto(String estado,int proyecto_id) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("update proyectos set estado=?" + "where id_proyecto=?");
// Parameters start with 1 
            preparedStatement.setString(1, estado);
            preparedStatement.setInt(2, proyecto_id);            
            
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);            
        }
    }

    
     public List<Proyecto> getProyectoById(int userId) {
        List<Proyecto> proyectodb = new ArrayList<Proyecto>();
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select * from proyectos where id_cliente=?");
            preparedStatement.setInt(1, userId);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Proyecto proyecto = new Proyecto();
                
                proyecto.setId_proyecto(rs.getInt("id_proyecto"));
                proyecto.setNombre(rs.getString("nombre"));
                proyecto.setDescripcion(rs.getString("descripcion"));
                proyecto.setPresupueto(rs.getFloat("presupuesto"));
                proyecto.setFecha_subida(rs.getDate("fecha_subida"));
                proyecto.setFecha_limite(rs.getString("fecha_limite"));
                proyecto.setDocumento(rs.getString("documento"));
                proyecto.setEstado(rs.getString("estado"));
                proyecto.setId_cliente(rs.getInt("id_cliente"));
                proyecto.setExtension_documento(rs.getString("extension_documento"));
                proyectodb.add(proyecto);
            
            }
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
        return proyectodb;
    }
     
     public Proyecto getProyectoDetalle(int id_proyecto){
        Proyecto proyecto = new Proyecto();
        
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select * from proyectos where id_proyecto=?");
            preparedStatement.setInt(1, id_proyecto);
            
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                    proyecto.setId_proyecto(rs.getInt("id_proyecto"));
                proyecto.setNombre(rs.getString("nombre"));
                proyecto.setDescripcion(rs.getString("descripcion"));
                proyecto.setPresupueto(rs.getFloat("presupuesto"));
                proyecto.setFecha_subida(rs.getDate("fecha_subida"));
                proyecto.setFecha_limite(rs.getString("fecha_limite"));
                proyecto.setDocumento(rs.getString("documento"));
                proyecto.setEstado(rs.getString("estado"));
                proyecto.setId_cliente(rs.getInt("id_cliente"));
                
            }
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
        return proyecto;
    }
     
    public List<Proyecto> getAllProyecto() {
        List<Proyecto> proyectodb = new ArrayList<Proyecto>();
        try {
            Statement statement = connection.createStatement();
                ResultSet rs = statement.executeQuery("select * from proyectos where estado='Inicio'");
            
            while (rs.next()) {
                Proyecto proyecto = new Proyecto();
                
                proyecto.setId_proyecto(rs.getInt("id_proyecto"));
                proyecto.setNombre(rs.getString("nombre"));
                proyecto.setDescripcion(rs.getString("descripcion"));
                proyecto.setPresupueto(rs.getFloat("presupuesto"));
                proyecto.setFecha_subida(rs.getDate("fecha_subida"));
                proyecto.setFecha_limite(rs.getString("fecha_limite"));
                proyecto.setDocumento(rs.getString("documento"));
                proyecto.setEstado(rs.getString("estado"));
                proyecto.setId_cliente(rs.getInt("id_cliente"));
                proyecto.setExtension_documento(rs.getString("extension_documento"));
                proyectodb.add(proyecto);
            
            }
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
        return proyectodb;
    }
    
    public int getNumProyectoEjecucion(int id_usuario){
        int resultado = 0;
        
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select count(*) from proyectos where id_cliente=? and estado!='Inicio' and estado!='Pendiente' and estado!='Completado' ");
            preparedStatement.setInt(1, id_usuario);
            
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                    
                resultado = rs.getInt("count(*)");
            }
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
        return resultado;
    }
    
    public int getNumProyectoCompletados(int id_usuario){
        int resultado = 0;
        
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select count(*) from proyectos where id_cliente=? and estado='Completado' ");
            preparedStatement.setInt(1, id_usuario);
            
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                    
                resultado = rs.getInt("count(*)");
            }
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
        return resultado;
    }
    /*public void updateProveedor(Proyecto proyecto) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("update proveedor set firstname=?, lastname=?, email=?" + "where userid=?");
// Parameters start with 1 
           preparedStatement.setString(1, user.getNombre());
            preparedStatement.setString(2, user.getApellidos());            
            preparedStatement.setString(3, user.getContraseña());
            preparedStatement.setDate(4, (Date) user.getFecha_registro());
            preparedStatement.setString(5, user.getEmail());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);            
        }
    }

    public List<Proyecto> getAllProyecto() {
        List<Proyecto> proyectodb = new ArrayList<Proyecto>();
        if (connection != null)
        {
            try {
                Statement statement = connection.createStatement();
                ResultSet rs = statement.executeQuery("select * from proyecto;");
                while (rs.next()) {
                    Proyecto proyecto = new Proyecto();
                    user.setId_usuario(rs.getInt("id_usuario"));
                    user.setNombre(rs.getString("nombre"));
                    user.setApellidos(rs.getString("apellidos"));
                    user.setContraseña(rs.getString("contraseña"));
                    user.setFecha_registro(rs.getDate("fecha_registro"));
                    user.setEmail(rs.getString("email"));
                    proyecto.addProyecto(proyecto);
                }
            } catch (SQLException e) {
                Log.logdb.error("SQL Exception: " + e);            
            }
            return proyectodb;
        }
        else
        {
            Log.logdb.error("No hay conexion con la bbdd");
            return null;
        }
       
    }

   
    
    
    }*/
    
    
}


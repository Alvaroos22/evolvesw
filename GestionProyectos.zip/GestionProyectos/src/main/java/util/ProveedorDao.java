
package util;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.Proveedor;
import util.DbUtil;
import util.Log;

public class ProveedorDao {

    private Connection connection;

    public ProveedorDao() {
        connection = DbUtil.getConnection();
    }

    public void addProveedor(Proveedor user) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("insert into proveedor(nombre,contraseña,fecha_registro,email) values (?, ?, ?,? )");
// Parameters start with 1 
            preparedStatement.setString(1, user.getNombre());
            //preparedStatement.setString(2, user.getApellidos());            
            preparedStatement.setString(2, user.getContraseña());
            preparedStatement.setDate(3, (Date) user.getFecha_registro());
            preparedStatement.setString(4, user.getEmail());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
    }

    public void deleteUser(int userId) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("delete from cliente where id_usuario=?");
            // Parameters start with 1 
            preparedStatement.setInt(1, userId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
    }

    public void updateProveedor(Proveedor user) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("update proveedor set firstname=?, lastname=?, email=?" + "where userid=?");
// Parameters start with 1 
           preparedStatement.setString(1, user.getNombre());
            preparedStatement.setString(2, user.getApellidos());            
            preparedStatement.setString(3, user.getContraseña());
            preparedStatement.setDate(4, (Date) user.getFecha_registro());
            preparedStatement.setString(5, user.getEmail());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);            
        }
    }

    public List<Proveedor> getAllProveedor() {
        List<Proveedor> userdb = new ArrayList<Proveedor>();
        if (connection != null)
        {
            try {
                Statement statement = connection.createStatement();
                ResultSet rs = statement.executeQuery("select * from proveedor;");
                while (rs.next()) {
                    Proveedor user = new Proveedor();
                    user.setId_usuario(rs.getInt("id_usuario"));
                    user.setNombre(rs.getString("nombre"));
                    user.setApellidos(rs.getString("apellidos"));
                    user.setContraseña(rs.getString("contraseña"));
                    user.setFecha_registro(rs.getDate("fecha_registro"));
                    user.setEmail(rs.getString("email"));
                    userdb.add(user);
                }
            } catch (SQLException e) {
                Log.logdb.error("SQL Exception: " + e);            
            }
            return userdb;
        }
        else
        {
            Log.logdb.error("No hay conexion con la bbdd");
            return null;
        }
       
    }

    public Proveedor getProveedorById(int userId) {
        Proveedor user = new Proveedor();
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select * from proveedor where id_usuario=?");
            preparedStatement.setInt(1, userId);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                    user.setId_usuario(rs.getInt("id_usuario"));
                    user.setNombre(rs.getString("nombre"));
                    user.setApellidos(rs.getString("apellidos"));
                    user.setContraseña(rs.getString("contraseña"));
                    user.setFecha_registro(rs.getDate("fecha_registro"));
                    user.setEmail(rs.getString("email"));
            }
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
        return user;
    }
    
    public Proveedor getProveedorByEmail(String email) {
        Proveedor user = new Proveedor();
        user.setEmail("");
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select * from proveedor where email=?");
            preparedStatement.setString(1, email);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                    user.setId_usuario(rs.getInt("id_usuario"));
                    user.setNombre(rs.getString("nombre"));
                    user.setApellidos(rs.getString("apellidos"));
                    user.setContraseña(rs.getString("contraseña"));
                    user.setFecha_registro(rs.getDate("fecha_registro"));
                    user.setEmail(rs.getString("email"));
            }
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
        return user;
    }
    
    public Proveedor getProveedorRegister(String nombre, String contrasenia) {
        Proveedor user = new Proveedor();
        user.setEmail("");
        user.setNombre("");
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select * from proveedor where nombre=? and contraseña=?");
            preparedStatement.setString(1, nombre);
            preparedStatement.setString(2, contrasenia);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                    user.setId_usuario(rs.getInt("id_usuario"));
                    user.setNombre(rs.getString("nombre"));
                    user.setApellidos(rs.getString("apellidos"));
                    user.setContraseña(rs.getString("contraseña"));
                    user.setFecha_registro(rs.getDate("fecha_registro"));
                    user.setEmail(rs.getString("email"));
            }
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
        return user;
    }
}

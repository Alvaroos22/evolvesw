
package util;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.Cliente;
import util.DbUtil;
import util.Log;

public class ClienteDao {

    private Connection connection;

    public ClienteDao() {
        connection = DbUtil.getConnection();
    }

    public void addUser(Cliente user) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("insert into cliente(nombre,contraseña,proyectos_publicados,fecha_registro,email) values (?, ?, ?,?,? )");
// Parameters start with 1 
            preparedStatement.setString(1, user.getNombre());
            //preparedStatement.setString(2, user.getApellidos());            
            preparedStatement.setString(2, user.getContraseña());
            preparedStatement.setInt(3, user.getProyectos_publicados());
            preparedStatement.setDate(4, (Date) user.getFecha_registro());
            preparedStatement.setString(5, user.getEmail());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
    }

    public void deleteUser(int userId) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("delete from cliente where id_usuario=?");
            // Parameters start with 1 
            preparedStatement.setInt(1, userId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
    }

    public void updateUser(Cliente user) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("update users set firstname=?, lastname=?, email=?" + "where userid=?");
// Parameters start with 1 
           preparedStatement.setString(1, user.getNombre());
            preparedStatement.setString(2, user.getApellidos());            
            preparedStatement.setString(3, user.getContraseña());
            preparedStatement.setInt(4, user.getProyectos_publicados());
            preparedStatement.setDate(5, (Date) user.getFecha_registro());
            preparedStatement.setString(6, user.getEmail());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);            
        }
    }

    public List<Cliente> getAllUsers() {
        List<Cliente> userdb = new ArrayList<Cliente>();
        if (connection != null)
        {
            try {
                Statement statement = connection.createStatement();
                ResultSet rs = statement.executeQuery("select * from cliente;");
                while (rs.next()) {
                    Cliente user = new Cliente();
                    user.setId_usuario(rs.getInt("id_usuario"));
                    user.setNombre(rs.getString("nombre"));
                    user.setApellidos(rs.getString("apellidos"));
                    user.setContraseña(rs.getString("contraseña"));
                    user.setProyectos_publicados(rs.getInt("proyectos_publicados"));
                    user.setFecha_registro(rs.getDate("fecha_registro"));
                    user.setEmail(rs.getString("email"));
                    userdb.add(user);
                }
            } catch (SQLException e) {
                Log.logdb.error("SQL Exception: " + e);            
            }
            return userdb;
        }
        else
        {
            Log.logdb.error("No hay conexion con la bbdd");
            return null;
        }
       
    }

    public Cliente getUserById(int userId) {
        Cliente user = new Cliente();
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select * from cliente where id_usuario=?");
            preparedStatement.setInt(1, userId);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                    user.setId_usuario(rs.getInt("id_usuario"));
                    user.setNombre(rs.getString("nombre"));
                    user.setApellidos(rs.getString("apellidos"));
                    user.setContraseña(rs.getString("contraseña"));
                    user.setProyectos_publicados(rs.getInt("proyectos_publicados"));
                    user.setFecha_registro(rs.getDate("fecha_registro"));
                    user.setEmail(rs.getString("email"));
            }
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
        return user;
    }
    
    public Cliente getUserByEmail(String email) {
        Cliente user = new Cliente();
        user.setEmail("");
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select * from cliente where email=?");
            preparedStatement.setString(1, email);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                    user.setId_usuario(rs.getInt("id_usuario"));
                    user.setNombre(rs.getString("nombre"));
                    user.setApellidos(rs.getString("apellidos"));
                    user.setContraseña(rs.getString("contraseña"));
                    user.setProyectos_publicados(rs.getInt("proyectos_publicados"));
                    user.setFecha_registro(rs.getDate("fecha_registro"));
                    user.setEmail(rs.getString("email"));
            }
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
        return user;
    }
    
    public Cliente getUserRegister(String nombre, String contrasenia) {
        Cliente user = new Cliente();
        user.setEmail("");
        user.setNombre("");
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select * from cliente where nombre=? and contraseña=?");
            preparedStatement.setString(1, nombre);
            preparedStatement.setString(2, contrasenia);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                    user.setId_usuario(rs.getInt("id_usuario"));
                    user.setNombre(rs.getString("nombre"));
                    user.setApellidos(rs.getString("apellidos"));
                    user.setContraseña(rs.getString("contraseña"));
                    user.setProyectos_publicados(rs.getInt("proyectos_publicados"));
                    user.setFecha_registro(rs.getDate("fecha_registro"));
                    user.setEmail(rs.getString("email"));
            }
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
        return user;
    }
}

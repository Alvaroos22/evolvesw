package util;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.Presupuesto;
import model.Proyecto;
import util.DbUtil;
import util.Log;

public class PresupuestoDao {

    private Connection connection;

    public PresupuestoDao() {
        connection = DbUtil.getConnection();
    }

    public int addPresupuesto(Presupuesto presupuesto) {
        int insertId = 0;
        try {
            
            PreparedStatement preparedStatement = connection.prepareStatement("insert into presupuesto(archivo,comentarios,estado,id_proyecto,id_proveedor,fecha_propuesta,nombre_proyecto,aceptada) values (?, ?, ?,?,?,?,?,?)");
// Parameters start with 1 
            preparedStatement.setString(1, presupuesto.getArchivo());
            //preparedStatement.setString(2, user.getApellidos());            
            preparedStatement.setString(2, presupuesto.getComentarios());
            preparedStatement.setString(3,presupuesto.getEstado());
            preparedStatement.setInt(4,presupuesto.getId_proyecto());
            preparedStatement.setInt(5,presupuesto.getId_proveedor());
            preparedStatement.setDate(6, (Date) presupuesto.getFecha_propuesta());
            preparedStatement.setString(7,presupuesto.getNombreProyecto());
            preparedStatement.setString(8,presupuesto.getAceptada());
            preparedStatement.executeUpdate();
            
            PreparedStatement getLastInsertId = connection.prepareStatement("SELECT LAST_INSERT_ID()");
            ResultSet rs = getLastInsertId.executeQuery();
            if (rs.next()){
                    insertId = (int) rs.getLong("last_insert_id()");  
                    
            }
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
        
        return insertId;
    }

    public void deletePresupuesto(int userId) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("delete from presupuesto where id_presupuesto=?");
            // Parameters start with 1 
            preparedStatement.setInt(1, userId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
    }
    
    public void updatePresupuestoDocumento(String documento,int proyecto_id) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("update presupuesto set archivo=?" + "where id_presupuesto=?");
// Parameters start with 1 
            preparedStatement.setString(1, documento);
            preparedStatement.setInt(2, proyecto_id);            
            
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);            
        }
    }
    
    public void updatePresupuestoComentario(String comentario,int proyecto_id) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("update presupuesto set comentarios=?" + "where id_presupuesto=?");
// Parameters start with 1 
            preparedStatement.setString(1, comentario);
            preparedStatement.setInt(2, proyecto_id);            
            
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);            
        }
    }
    
    public void updatePresupuestoEstado(String estado,int proyecto_id) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("update presupuesto set estado=?" + "where id_presupuesto=?");
// Parameters start with 1 
            preparedStatement.setString(1, estado);
            preparedStatement.setInt(2, proyecto_id);            
            
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);            
        }
    }
    
    public void updatePresupuestoAceptada(String aceptada,int proyecto_id) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("update presupuesto set aceptada=?" + "where id_presupuesto=?");
// Parameters start with 1 
            preparedStatement.setString(1, aceptada);
            preparedStatement.setInt(2, proyecto_id);            
            
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);            
        }
    }

    
     public List<Presupuesto> getPresupuestoById(int userId) {
        List<Presupuesto> presupuestodb = new ArrayList<Presupuesto>();
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select * from presupuesto where id_proveedor=?");
            preparedStatement.setInt(1, userId);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Presupuesto presupuesto = new Presupuesto();
                
                
                presupuesto.setId_presupuesto(rs.getInt("id_presupuesto"));
                presupuesto.setArchivo(rs.getString("archivo"));
                presupuesto.setComentarios(rs.getString("comentarios"));
                presupuesto.setEstado(rs.getString("estado"));
                presupuesto.setId_proyecto(rs.getInt("id_proyecto"));
                presupuesto.setId_proveedor(rs.getInt("id_proveedor"));
                presupuesto.setFecha_propuesta(rs.getDate("fecha_propuesta"));
                presupuesto.setNombreProyecto(rs.getString("nombre_proyecto"));
                presupuesto.setAceptada(rs.getString("aceptada"));
                
                presupuestodb.add(presupuesto);
            
            }
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
        return presupuestodb;
    }
     
     
     
    public List<Presupuesto> getAllProyecto() {
        List<Presupuesto> presupuestodb = new ArrayList<Presupuesto>();
        try {
            Statement statement = connection.createStatement();
                ResultSet rs = statement.executeQuery("select * from presupuesto ");
            
            while (rs.next()) {
                Presupuesto presupuesto = new Presupuesto();
                
                presupuesto.setId_presupuesto(rs.getInt("id_presupuesto"));
                presupuesto.setArchivo(rs.getString("archivo"));
                presupuesto.setComentarios(rs.getString("comentarios"));
                presupuesto.setEstado(rs.getString("estado"));
                presupuesto.setId_proyecto(rs.getInt("id_proyecto"));
                presupuesto.setId_proveedor(rs.getInt("id_proveedor"));
                presupuesto.setFecha_propuesta(rs.getDate("fecha_propuesta"));
                presupuesto.setNombreProyecto(rs.getString("nombre_proyecto"));
                presupuesto.setAceptada(rs.getString("aceptada"));
                presupuestodb.add(presupuesto);
            
            }
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
        return presupuestodb;
    } 
    
    public int getNumProyectoEjecucion(int id_usuario){
        int resultado = 0;
        
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select count(*) from presupuesto where id_proveedor=? and estado!='Inicio' and estado!='Pendiente' and estado!='Completado' ");
            preparedStatement.setInt(1, id_usuario);
            
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                    
                resultado = rs.getInt("count(*)");
            }
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
        return resultado;
    }
    
    public int getNumProyectoCompletados(int id_usuario){
        int resultado = 0;
        
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select count(*) AS rowcount from presupuesto where id_proveedor=? and estado='Completado' ");
            preparedStatement.setInt(1, id_usuario);
            
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                    
                resultado = rs.getInt("rowcount");
            }
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
        return resultado;
    }
    
    public Presupuesto getPresupuestoDetalle(int id_proyecto){
         Presupuesto presupuesto = new Presupuesto();
        
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select * from presupuesto where id_proyecto=?");
            preparedStatement.setInt(1, id_proyecto);
            
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                   
                
                presupuesto.setId_presupuesto(rs.getInt("id_presupuesto"));
                presupuesto.setArchivo(rs.getString("archivo"));
                presupuesto.setComentarios(rs.getString("comentarios"));
                presupuesto.setEstado(rs.getString("estado"));
                presupuesto.setId_proyecto(rs.getInt("id_proyecto"));
                presupuesto.setId_proveedor(rs.getInt("id_proveedor"));
                presupuesto.setFecha_propuesta(rs.getDate("fecha_propuesta"));
                presupuesto.setNombreProyecto(rs.getString("nombre_proyecto"));
                presupuesto.setAceptada(rs.getString("aceptada"));
            }
        } catch (SQLException e) {
            Log.logdb.error("SQL Exception: " + e);
        }
        return presupuesto;
    }
   
    
    
}

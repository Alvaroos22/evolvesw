
package model;

import java.util.Date;


public class Presupuesto {
    
    private int id_presupuesto;
    private String archivo;
    private String comentarios;
    private String estado;
    private int id_proyecto;
    private int id_proveedor;
    private Date fecha_propuesta;
    private String nombreProyecto;
    private String aceptada;

    public String getAceptada() {
        return aceptada;
    }

    public void setAceptada(String aceptada) {
        this.aceptada = aceptada;
    }

    public String getNombreProyecto() {
        return nombreProyecto;
    }

    public void setNombreProyecto(String nombreProyecto) {
        this.nombreProyecto = nombreProyecto;
    }

    

    public int getId_presupuesto() {
        return id_presupuesto;
    }

    public void setId_presupuesto(int id_presupuesto) {
        this.id_presupuesto = id_presupuesto;
    }

    public String getArchivo() {
        return archivo;
    }

    public void setArchivo(String archivo) {
        this.archivo = archivo;
    }

    public String getComentarios() {
        return comentarios;
    }

    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getId_proyecto() {
        return id_proyecto;
    }

    public void setId_proyecto(int id_proyecto) {
        this.id_proyecto = id_proyecto;
    }

    public int getId_proveedor() {
        return id_proveedor;
    }

    public void setId_proveedor(int id_proveedor) {
        this.id_proveedor = id_proveedor;
    }

    public Date getFecha_propuesta() {
        return fecha_propuesta;
    }

    public void setFecha_propuesta(Date fecha_propuesta) {
        this.fecha_propuesta = fecha_propuesta;
    }

    @Override
    public String toString() {
        return "Presupuesto{" + "id_presupuesto=" + id_presupuesto + ", archivo=" + archivo + ", comentarios=" + comentarios + ", estado=" + estado + ", id_proyecto=" + id_proyecto + ", id_proveedor=" + id_proveedor + ", fecha_propuesta=" + fecha_propuesta + '}';
    }
    
}

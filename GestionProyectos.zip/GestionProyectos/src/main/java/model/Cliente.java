
package model;


import java.util.Date;

public class Cliente {

    private int id_usuario;
    private String nombre;
    private String apellidos;
    private String contraseña;
    private String email;
    private Date fecha_registro;
    private int proyectos_publicados;

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getFecha_registro() {
        return fecha_registro;
    }

    public void setFecha_registro(Date fecha_registro) {
        this.fecha_registro = fecha_registro;
    }

    public int getProyectos_publicados() {
        return proyectos_publicados;
    }

    public void setProyectos_publicados(int proyectos_publicados) {
        this.proyectos_publicados = proyectos_publicados;
    }
    

    
    @Override
    public String toString() {
        return "User [id_usuario=" + id_usuario + ", nombre=" + nombre + ", apellidos=" + apellidos + ", contraseña=" + contraseña + ", email=" + email + ", fecha_registro=" + fecha_registro +  ", proyectos_publicados=" + proyectos_publicados +"]";
    }
}

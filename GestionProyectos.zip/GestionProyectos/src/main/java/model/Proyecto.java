
package model;

import java.sql.Blob;
import java.util.Date;


public class Proyecto {
    
    private int id_proyecto;
    private int id_cliente;
    private String nombre;
    private String descripcion;
    private Date fecha_subida; 
    private String fecha_limite;
    private String estado;
    private Float presupueto;
    private String documento;
    private String extension_documento;

    public int getId_proyecto() {
        return id_proyecto;
    }

    public void setId_proyecto(int id_proyecto) {
        this.id_proyecto = id_proyecto;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getFecha_subida() {
        return fecha_subida;
    }

    public void setFecha_subida(Date fecha_subida) {
        this.fecha_subida = fecha_subida;
    }

    public String getFecha_limite() {
        return fecha_limite;
    }

    public void setFecha_limite(String fecha_limite) {
        this.fecha_limite = fecha_limite;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Float getPresupueto() {
        return presupueto;
    }

    public void setPresupueto(Float presupueto) {
        this.presupueto = presupueto;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getExtension_documento() {
        return extension_documento;
    }

    public void setExtension_documento(String extension_documento) {
        this.extension_documento = extension_documento;
    }

    @Override
    public String toString() {
        return "Proyecto{" + "id_proyecto=" + id_proyecto + ", id_cliente=" + id_cliente + ", nombre=" + nombre + ", descripcion=" + descripcion + ", fecha_subida=" + fecha_subida + ", fecha_limite=" + fecha_limite + ", estado=" + estado + ", presupueto=" + presupueto + ", documento=" + documento + '}';
    }
    
}

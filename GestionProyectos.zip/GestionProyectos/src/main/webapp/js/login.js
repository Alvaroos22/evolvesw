$( document ).ready(function() {
    
    $( "#inicio" ).click(function() {

      $("#accion").val("inicio");
    });

    $( "#registro" ).click(function() {
       $("#accion").val("registro");
    });
    
    $( "#botonInicio" ).click(function() {
         $( "#formlogin" ).submit();
    });
    
    $( "#botonRegistro" ).click(function() {
       $( "#formlogin" ).submit();
    });
    
    $("#Cliente").click(function () {	 
         $("#origen").val(($('input:radio[name=guessType]:checked').val()));
			
    });
    
    $("#Proveedor").click(function () {	 
         $("#origen").val(($('input:radio[name=guessType]:checked').val()));
			
    });
    
    if($("#validacion").val() == "Ya existe"){
        
        if($("#accionValidar").val()=="registro"){
            let register = document.querySelector(".register");
            document.querySelector(".Content__formLogin--body").classList.remove("active");
            document.querySelector(".Content__formRegister--body").classList.add("active");
            document.querySelector(".Content__form--header-login").classList.remove("active");
            document.querySelector(".Content__form--header-register").classList.add("active");
            document.querySelector(".Content__formForgotPass--body").classList.remove("active");
            document.querySelector(".Content__formLogin--footer-forgotPassword").classList.remove("active");
            
            alert("El email que intentas dar de alta ya existe");

            
        }
        
    }else if ($("#validacion").val() == "No existe login"){
        
        if($("#accionValidar").val()=="inicio"){
            let login = document.querySelector(".login"); 
             document.querySelector(".Content__formRegister--body").classList.remove("active");
    document.querySelector(".Content__formLogin--body").classList.add("active");
    document.querySelector(".Content__form--header-register").classList.remove("active");
    document.querySelector(".Content__form--header-login").classList.add("active");
    document.querySelector(".Content__formForgotPass--body").classList.remove("active");
    document.querySelector(".Content__formLogin--footer-forgotPassword").classList.remove("active");
            
            alert("Usuario o contraseña son incorrectos");

            
        }
        
    }
    
});
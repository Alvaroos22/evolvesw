let login = document.querySelector(".login"); 
let register = document.querySelector(".register");
let forgotPass = document.querySelector(".forgotPass");

login.addEventListener("click",function(){
    document.querySelector(".Content__formRegister--body").classList.remove("active");
    document.querySelector(".Content__formLogin--body").classList.add("active");
    document.querySelector(".Content__form--header-register").classList.remove("active");
    document.querySelector(".Content__form--header-login").classList.add("active");
    document.querySelector(".Content__formForgotPass--body").classList.remove("active");
    document.querySelector(".Content__formLogin--footer-forgotPassword").classList.remove("active");
});
register.addEventListener("click",function(){
    document.querySelector(".Content__formLogin--body").classList.remove("active");
    document.querySelector(".Content__formRegister--body").classList.add("active");
    document.querySelector(".Content__form--header-login").classList.remove("active");
    document.querySelector(".Content__form--header-register").classList.add("active");
    document.querySelector(".Content__formForgotPass--body").classList.remove("active");
    document.querySelector(".Content__formLogin--footer-forgotPassword").classList.remove("active");
});
forgotPass.addEventListener("click",function(){
    document.querySelector(".Content__formLogin--body").classList.remove("active");
    document.querySelector(".Content__formRegister--body").classList.remove("active");
    document.querySelector(".Content__formForgotPass--body").classList.add("active");
    document.querySelector(".Content__form--header-login").classList.remove("active");
    document.querySelector(".Content__form--header-register").classList.remove("active");
    document.querySelector(".Content__formLogin--footer-forgotPassword").classList.add("active");
});



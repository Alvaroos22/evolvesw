

$( document ).ready(function() {
    
    $( "#publicar" ).click(function() {

      
    });

  
    
});



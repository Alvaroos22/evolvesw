$( document ).ready(function() {
    
    
    if($("#origen").val()=="Cliente"){
        $("#nombre").text($("#nombreCliente").val());
        $("#email").text($("#emailCliente").val());
        $("#time").val($("#fechaCliente").val());
        $("#desarrolloProceso").text($("#proyectoEjecucionCliente").val());
        $("#desarrolloTerminado").text($("#proyectoTerminadoCliente").val());
        
    }else{
        $("#nombre").text($("#nombreProveedor").val());
        $("#email").text($("#emailProveedor").val());
        $("#time").val($("#fechaProveedor").val());
        $("#desarrolloProceso").text($("#proyectoEjecucionProveedor").val());
        $("#desarrolloTerminado").text($("#proyectoTerminadoProveedor").val());
    }
    
     $("#origenInformacion").text($("#origen").val());
});
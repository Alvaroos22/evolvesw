$(document).ready(function() {
    
             document.querySelector("#analysisImpacto").addEventListener("click",function(){
                    $("#AceptarForm").submit();
    
            });
            document.querySelector("#analysisFuncionalReject").addEventListener("click",function(){
                 $("#RechazarForm").submit();
            });
 });

   
  
   
   /*document.querySelector("#analysisFuncional").addEventListener("click",function(){
    functionalAnalysis.classList.add("button-active");
    bodyFuctionalAnalysis.classList.remove("active");
    bodyImpactAnalysis.classList.remove("active");
    bodyTestPlan.classList.add("active");
    });
    
    document.querySelector("#analysisFuncionalReject").addEventListener("click",function(){
    impactAnalysis.classList.remove("button-active");
    testPlanButton.classList.add("active");
    bodyFuctionalAnalysis.classList.remove("active");
    bodyImpactAnalysis.classList.add("active");
    });
    
    document.querySelector("#planPruebasReject").addEventListener("click",function(){
    functionalAnalysis.classList.remove("button-active");
    bodyFuctionalAnalysis.classList.add("active");
    bodyImpactAnalysis.classList.remove("active");
    bodyTestPlan.classList.remove("active");
    });*/
/*});*/

